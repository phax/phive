# peppol-bis

Please report any issues by email to rfc[at]peppol[dot]eu - thank you!

Files for PEPPOL BIS - http://www.peppol.eu
  * Schematron
    * Schematron code files
    * Official examples
    * Test
      * Test files
      * Test specification
  * build files
