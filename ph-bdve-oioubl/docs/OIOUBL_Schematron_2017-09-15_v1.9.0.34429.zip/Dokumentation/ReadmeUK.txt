﻿ReadmeUK.txt
Revision: 2017.06.15 by Jacob Lund Mogensen, Charlotte Dahl Skovhus and Peter Sone Koldkjær (mySupply ApS for Digitaliseringsstyrelsen).


OIOUBL-2.02 schematron stylesheets
----------------------------------


1.0 Purpose and usage
---------------------
Validation of OIOUBL instances.
The following OIOUBL document types are currently supported:
    ApplicationResponse.xml
    Catalogue.xml
    CatalogueDeletion.xml
    CatalogueItemSpecificationUpdate.xml
    CataloguePricingUpdate.xml
    CatalogueRequest.xml
    CreditNote.xml
    Invoice.xml
    Order.xml
    OrderCancellation.xml
    OrderChange.xml
    OrderResponse.xml
    OrderResponseSimple.xml
    Reminder.xml
    Statement.xml
    UtilityStatement.xml

To validate, execute the following command (shown for Invoice):
msxsl.exe <XML document filename> OIOUBL_Invoice_Schematron.xsl -o result.xml

If the validation is successful, only the title is written to result.xml; otherwise the errors are listed.

To validate PEPPOL documents, a XSLT2 tool must be used, using the PEPPOL validation artifacts (https://joinup.ec.europa.eu/svn/peppol/Validation%20Resources/BIS%20v2/).


2.0 Prerequisites
-----------------
The instance file must validate OK with the UBL-2.0 XSD schema.
For DespatchAdvice the UBL-2.1 XSD must be used.


3.0 Release Notes
-----------------
Schematron changes:
1795: Add new country codes: BQ,CW,SS,SX.
      Removed discontinued country codes: AN,BL,MF.
1804: Allow negative MultiplierFactorNumeric for Price/AllowanceCharge in Credit Note
1834: New code list for VAT categories (OIOUBL_Kodeliste_TaxCategoryID-1.3)
      - New in candidate release: Added 3083, 3084, 3639 to TaxCategoryId 1.3 Codelist
1834: New code list for TaxSchemeID (OIOUBL_Kodeliste_TaxSchemeID-1.5)
1927: The folder 'UdvidetIndkoebsproces_beta' has been removed from the release package


4.0 Revision log
----------------
2014.09.15  Version 1.6.0 released.
2015.09.15  Version 1.7.0 released.
2016.09.15  Version 1.8.0 released.
2017.09.15  Version 1.9.0 released.


5.0 Your feedback
-----------------
Please post your comments and feedback to the following email address:
    support@nemhandel.dk

Thanks!
