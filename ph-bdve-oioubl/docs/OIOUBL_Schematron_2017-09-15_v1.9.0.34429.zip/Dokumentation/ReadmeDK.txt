﻿ReadmeDK.txt
Revideret: 15.06.2017 af Jacob Lund Mogensen, Charlotte Dahl Skovhus og Peter Sone Koldkjær (mySupply ApS for Digitaliseringsstyrelsen).


OIOUBL-2.02 schematron validerings-stylesheets
----------------------------------------------


1.0 Anvendelse
--------------
Anvendes til at validere om XML eksempelfil overholder reglerne i OIOUBL subset.
Følgende OIOUBL dokumenttyper kan valideres:
    ApplicationResponse.xml
    Catalogue.xml
    CatalogueDeletion.xml
    CatalogueItemSpecificationUpdate.xml
    CataloguePricingUpdate.xml
    CatalogueRequest.xml
    CreditNote.xml
    Invoice.xml
    Order.xml
    OrderCancellation.xml
    OrderChange.xml
    OrderResponse.xml
    OrderResponseSimple.xml
    Reminder.xml
    Statement.xml
    UtilityStatement.xml

Et dokument, f.eks. en faktura, valideres således:
msxsl.exe <XML dokument filnavn> OIOUBL_Invoice_Schematron.xsl -o resultat.xml

Hvis fakturaen validerer OK skrives alene en overskrift til resultat.xml, ellers listes alle fundne fejl.

For at kunne validere PEPPOL dokumenter, skal et XSLT2 værktøj benyttes sammen med PEPPOL validation artifacts (https://joinup.ec.europa.eu/svn/peppol/Validation%20Resources/BIS%20v2/)


2.0 Forudsætninger
------------------
Det forudsættes at eksempelfilen er valideret korrekt med det tilhørende UBL-2.0 XSD schema inden schematron stylesheetet anvendes.
Og for DespatchAdvice UBL-2.1 XSD inden schematron stylesheetet anvendes.


3.0 Release Notes
-----------------
Schematron ændringer:
1795: Tilføje nye landekoder: BQ,CW,SS,SX.
      Fjernet udgåede landekoder: AN,BL,MF.
1804: Tillad negativ MultiplierFactorNumeric for Price/AllowanceCharge i Kreditnota
1834: Ny kodeliste for afgiftskategorier (OIOUBL_Kodeliste_TaxCategoryID-1.3)
      - Nyt i candidate release: Tilføjet 3083, 3084, 3639 til TaxCategoryId 1.3 kodelisten
1834: Ny kodeliste for TaxSchemeID (OIOUBL_Kodeliste_TaxSchemeID-1.5)
1927: Mappen 'UdvidetIndkoebsproces_beta' er fjernet fra release-pakken


4.0 Revisionslog
----------------
2014.09.15  Version 1.6.0 frigivet.
2015.09.15  Version 1.7.0 frigivet.
2016.09.15  Version 1.8.0 frigivet.
2017.09.15  Version 1.9.0 frigivet.


5.0 Rapportering af fejl og mangler etc.
----------------------------------------
Information om fejl, mangler, og andet relevant, modtages meget gerne på følgende mailadresse:
    support@nemhandel.dk

På forhånd tak!
