#!/bin/sh

rm -r /target/guides/order-agreement/1.0/peppol
rm -r /target/guides/punch-out/1.0/peppol
