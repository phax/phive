Please make sure this box is checked before submitting your issue - thank you!

- [ ] Issue is related to guides or validation part of EHF in post-award.

Issues related to PEPPOL BIS or rules part of PEPPOL BIS must be sent to rfc@peppol.eu.

Your issue here:
