docker run --rm -it -v $(pwd):/documents -e "pdf=false" difi/asciidoctor
