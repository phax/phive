docker run --rm -it -v $(pwd):/src difi/vefa-validator build -x -t -a rules,guides /src
